package com.example.quota.service;

import com.example.quota.model.QuotaData;
import io.kubernetes.client.openapi.ApiClient;
import io.kubernetes.client.openapi.Configuration;
import io.kubernetes.client.openapi.apis.CoreV1Api;
import io.kubernetes.client.openapi.models.*;
import io.kubernetes.client.util.Config;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class KubernetesService {

    public QuotaData getQuota(String namespace) throws Exception {
        ApiClient client = Config.defaultClient();
        Configuration.setDefaultApiClient(client);
        CoreV1Api api = new CoreV1Api();

        V1ResourceQuotaList quotas = api.listNamespacedResourceQuota(namespace, null, null, null, null, null, null, null, null, null, false);
        if (quotas.getItems().isEmpty()) return null;

        V1ResourceQuota quota = quotas.getItems().get(0);
        Map<String, Quantity> used = quota.getStatus().getUsed();
        Map<String, Quantity> hard = quota.getStatus().getHard();

        double reqCpuUsed = parseCpu(used.get("requests.cpu"));
        double reqCpuHard = parseCpu(hard.get("requests.cpu"));
        double reqMemUsed = parseMemory(used.get("requests.memory"));
        double reqMemHard = parseMemory(hard.get("requests.memory"));
        double limCpuUsed = parseCpu(used.get("limits.cpu"));
        double limCpuHard = parseCpu(hard.get("limits.cpu"));
        double limMemUsed = parseMemory(used.get("limits.memory"));
        double limMemHard = parseMemory(hard.get("limits.memory"));

        return new QuotaData(namespace,
                reqCpuUsed, reqCpuHard,
                reqMemUsed, reqMemHard,
                limCpuUsed, limCpuHard,
                limMemUsed, limMemHard);
    }

    private double parseCpu(Quantity quantity) {
        if (quantity == null) return 0;
        return quantity.getNumber().doubleValue();
    }

    private double parseMemory(Quantity quantity) {
        if (quantity == null) return 0;
        String mem = quantity.getAmount();
        if (mem.endsWith("Mi")) return Double.parseDouble(mem.replace("Mi", ""));
        if (mem.endsWith("Gi")) return Double.parseDouble(mem.replace("Gi", "")) * 1024;
        return quantity.getNumber().doubleValue();
    }
}
