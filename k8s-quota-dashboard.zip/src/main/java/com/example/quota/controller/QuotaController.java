package com.example.quota.controller;

import com.example.quota.model.QuotaData;
import com.example.quota.service.KubernetesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class QuotaController {

    @Autowired
    KubernetesService service;

    @GetMapping("/quota")
    public String getQuota(Model model) throws Exception {
        QuotaData quota = service.getQuota("default"); // Change as needed
        model.addAttribute("quota", quota);
        return "quota";
    }
}
