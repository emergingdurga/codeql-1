package com.example.quota.model;

public class QuotaData {
    public String namespace;
    public double requestsCpuUsed;
    public double requestsCpuHard;
    public double requestsMemUsed;
    public double requestsMemHard;
    public double limitsCpuUsed;
    public double limitsCpuHard;
    public double limitsMemUsed;
    public double limitsMemHard;
    public boolean overThreshold;

    public QuotaData(String namespace,
                     double requestsCpuUsed, double requestsCpuHard,
                     double requestsMemUsed, double requestsMemHard,
                     double limitsCpuUsed, double limitsCpuHard,
                     double limitsMemUsed, double limitsMemHard) {
        this.namespace = namespace;
        this.requestsCpuUsed = requestsCpuUsed;
        this.requestsCpuHard = requestsCpuHard;
        this.requestsMemUsed = requestsMemUsed;
        this.requestsMemHard = requestsMemHard;
        this.limitsCpuUsed = limitsCpuUsed;
        this.limitsCpuHard = limitsCpuHard;
        this.limitsMemUsed = limitsMemUsed;
        this.limitsMemHard = limitsMemHard;

        this.overThreshold = isAboveThreshold(requestsCpuUsed, requestsCpuHard) ||
                             isAboveThreshold(requestsMemUsed, requestsMemHard) ||
                             isAboveThreshold(limitsCpuUsed, limitsCpuHard) ||
                             isAboveThreshold(limitsMemUsed, limitsMemHard);
    }

    private boolean isAboveThreshold(double used, double hard) {
        return hard > 0 && (used / hard) > 0.8;
    }
}
