package com.example.k8sdashboard.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.example.k8sdashboard.service.K8sService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class DashboardController {

    private final K8sService svc;

    public DashboardController(K8sService svc) {
        this.svc = svc;
    }

    @GetMapping("/")
    public String home(
        Model model,
        @RequestParam(defaultValue = "default") String namespace
    ) {
        JsonNode pods = svc.getPods(namespace);
        JsonNode nodes = svc.getNodes();
        model.addAttribute("pods", pods.path("items"));
        model.addAttribute("nodes", nodes.path("items"));
        model.addAttribute("namespace", namespace);
        return "index";
    }

    @GetMapping("/logs")
    public String logs(
        Model model,
        @RequestParam String namespace,
        @RequestParam String pod,
        @RequestParam String container
    ) {
        String log = svc.getLogs(namespace, pod, container);
        model.addAttribute("log", log);
        return "logs";
    }
}
