package com.example.k8sdashboard.service;

import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class K8sService {

    @Value("${k8s.api.url}")
    private String k8sApiUrl;

    private final RestTemplate rest = new RestTemplate();

    public JsonNode getPods(String ns) {
        return rest.getForObject(
            k8sApiUrl + "/api/v1/namespaces/" + ns + "/pods",
            JsonNode.class);
    }

    public JsonNode getNodes() {
        return rest.getForObject(k8sApiUrl + "/api/v1/nodes", JsonNode.class);
    }

    public String getLogs(String ns, String pod, String container) {
        return rest.getForObject(
            k8sApiUrl + "/api/v1/namespaces/" + ns + "/pods/" + pod + "/log?container=" + container,
            String.class);
    }
}
